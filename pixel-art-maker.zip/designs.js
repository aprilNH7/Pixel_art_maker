const $color = document.getElementById("colorPicker");
const $submit = document.getElementById("submit");
const $table = document.getElementById("pixelCanvas");
const $sizePicker = document.getElementById("sizePicker")

$sizePicker.addEventListener("click", (e) => {
  e.preventDefault();
	let height = document.getElementById("inputHeight");
	let width = document.getElementById("inputWidth");
	eraseGrid();
	makeGrid(width, height);
});

$table.addEventListener('click' , function(t) {
	if(t.target.nodeName === 'TD'){
	t.target.style.backgroundColor = $color.value;
 }
});

function makeGrid(width, height) {
	for(var n=0 ; n<height.value ; n++){
		const row = $table.insertRow (n);
		for( var m=0 ; m<width.value ; m++){
			const cell = row.insertCell (m);
			cell.addEventListener("click", (e) => {
				 cell.style.backgroundColor = color.value;
			 })
		}
	}
}

function eraseGrid(){
    while ($table.firstChild){
         $table.removeChild($table.firstChild);
		}
}
